package com.rs.micode;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button button;
    EditText editText2;
    EditText editText;
    Button copyButton;
    String num;
    CheckBox num0;
    CheckBox lower;
    CheckBox upper;
    CheckBox fuhao;
    TextView id;
    char c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button)findViewById(R.id.button);
        copyButton = (Button)findViewById(R.id.copyButton);
        editText2 = (EditText) findViewById(R.id.textEdit2);
        editText = (EditText)findViewById(R.id.textEdit);

        num0 = (CheckBox)findViewById(R.id.numButton);
        lower = (CheckBox)findViewById(R.id.lower);
        upper = (CheckBox)findViewById(R.id.upper);
        fuhao = (CheckBox)findViewById(R.id.fuhao);

        id = (TextView)findViewById(R.id.id);


        editText.setText("");


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num = editText.getText().toString();
                if (!num.equals("")) {
                    if(num.length()<=3) {
                        if(num0.isChecked()&lower.isChecked()&upper.isChecked()&!fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 94 + 33);
                                if ((c >= 48 && c <= 57) | (c >= 65 && c <= 90) | (c >= 97 && c <= 122)) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&!lower.isChecked()&!upper.isChecked()&!fuhao.isChecked()){
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 10 + 48);
                                    str = str + Character.toString(c);
                            }
                            editText2.setText(str);
                        }else if (!num0.isChecked()&lower.isChecked()&!upper.isChecked()&!fuhao.isChecked()){
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 26 + 97);
                                str = str + Character.toString(c);
                            }
                            editText2.setText(str);
                        }else if (!num0.isChecked()&!lower.isChecked()&upper.isChecked()&!fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 26 + 65);
                                str = str + Character.toString(c);
                            }
                            editText2.setText(str);
                        }else if (!num0.isChecked()&!lower.isChecked()&!upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                int x = (int) (Math.random() * 9);
                                switch (x){
                                    case 0:
                                        str = str + "!";
                                        break;
                                    case 1:
                                        str = str + "@";
                                        break;
                                    case 2:
                                        str = str + "#";
                                        break;
                                    case 3:
                                        str = str + "$";
                                        break;
                                    case 4:
                                        str = str + "%";
                                        break;
                                    case 5:
                                        str = str + "^";
                                        break;
                                    case 6:
                                        str = str + "&";
                                        break;
                                    case 7:
                                        str = str + "*";
                                        break;
                                    case 8:
                                        str = str + "_";
                                }
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&lower.isChecked()&!upper.isChecked()&!fuhao.isChecked()){
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 75 + 48);
                                if ((c >= 48 && c <= 57) | (c >= 97 && c <= 122))
                                str = str + Character.toString(c);
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&!lower.isChecked()&upper.isChecked()&!fuhao.isChecked()){
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 43 + 48);
                                if ((c >= 48 && c <= 57) | (c >= 65 && c <= 90))
                                    str = str + Character.toString(c);
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&!lower.isChecked()&!upper.isChecked()&fuhao.isChecked()){
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 48) && (c <= 57)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(!num0.isChecked()&lower.isChecked()&upper.isChecked()&!fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() *58+65);
                                if ( (c >= 65 && c <= 90) | (c >= 97 && c <= 122)) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(!num0.isChecked()&lower.isChecked()&!upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 97) && (c <= 122)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(!num0.isChecked()&!lower.isChecked()&upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 65) && (c <= 90)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&!lower.isChecked()&upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 48) && (c <= 57)) | ((c >= 65) && (c <= 90)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&lower.isChecked()&!upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 48) && (c <= 57)) | ((c >= 97) && (c <= 122)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(!num0.isChecked()&lower.isChecked()&upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 65) && (c <= 90)) | ((c >= 97) && (c <= 122)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }else if(num0.isChecked()&lower.isChecked()&upper.isChecked()&fuhao.isChecked()) {
                            int n = Integer.parseInt(num);
                            String str = "";
                            for (; str.length() <= n - 1; ) {
                                c = (char) (Math.random() * 127);
                                if (((c >= 97) && (c <= 122)) | ((c >= 48) & (c <= 57)) | ((c >= 65) && (c <= 90)) | (c == '!') | (c == '@') | (c == '#') | (c == '$') | (c == '%') | (c == '^') | (c == '&') | (c == '*') | (c == '_')) {
                                    str = str + Character.toString(c);
                                }
                            }
                            editText2.setText(str);
                        }
                    }else Toast.makeText(MainActivity.this,"输入有误",Toast.LENGTH_SHORT);
                }else Toast.makeText(MainActivity.this,"输入为空",Toast.LENGTH_SHORT);
            }
        });

        copyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboardManager = (ClipboardManager) getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
                String string = editText2.getText().toString();

                clipboardManager.setPrimaryClip(ClipData.newPlainText("text",string));

                Toast.makeText(MainActivity.this,editText2.getText().toString()+"已复制",Toast.LENGTH_SHORT).show();
            }
        });

        id.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboardManager = (ClipboardManager) getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
                String sid = "飘洋过海の鱼";

                clipboardManager.setPrimaryClip(ClipData.newPlainText("text",sid));

                Toast.makeText(MainActivity.this,"ID已复制",Toast.LENGTH_SHORT).show();
            }

        });
    }
}
